<?php

$title = 'ヘルパー拡張';
$description = 'コア,コアPluginに対して必要そうなヘルパーを追加します。';
// プラグイン管理画面へのパス
$adminLink = '/admin/ex_helper/ex_helper/index';
$installMessage = 'ExHelperをインストールします';
$author = 'kiyosue';
$url = 'http://www.itm.co.jp';

?>
